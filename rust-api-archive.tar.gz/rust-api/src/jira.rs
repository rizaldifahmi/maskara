use chrono::NaiveDate;
use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize, Clone)]
pub struct IssuesQuery {
    #[serde(default = "default_month")]
    pub month: String,
    #[serde(default)]
    pub project: Option<String>,
    #[serde(default = "default_true")]
    pub include_archived: bool,
}

fn default_month() -> String {
    chrono::Utc::now().format("%Y-%m").to_string()
}

fn default_true() -> bool {
    true
}

impl IssuesQuery {
    pub fn validate(&self) -> Result<(), String> {
        let parts: Vec<&str> = self.month.split('-').collect();
        if parts.len() != 2 {
            return Err(format!("month must be in YYYY-MM form, got: '{}'", self.month));
        }
        let year: i32 = parts[0].parse().map_err(|_| format!("invalid year in month: {}", self.month))?;
        let mon: u32 = parts[1].parse().map_err(|_| format!("invalid month in month: {}", self.month))?;
        if !(1..=12).contains(&mon) || !(2000..=2100).contains(&year) {
            return Err(format!("invalid month value: {}", self.month));
        }
        Ok(())
    }
}

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct JiraIssue {
    pub id: String,
    pub key: String,
    pub summary: String,
    pub status: JiraStatus,
    #[serde(default, rename = "created_at")]
    pub created: String,
    #[serde(default, rename = "updated_at")]
    pub updated: String,
    #[serde(default, rename = "epic_key")]
    pub epic: Option<String>,
}

#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct JiraStatus {
    pub name: String,
}

#[derive(Clone, Debug)]
pub struct JiraConfig {
    pub base_url: String,
    pub email: String,
    pub token: String,
}

impl JiraConfig {
    pub fn from_env() -> Self {
        Self {
            base_url: std::env::var("JIRA_URL").unwrap_or_default(),
            email: std::env::var("JIRA_EMAIL").unwrap_or_default(),
            token: std::env::var("JIRA_TOKEN").unwrap_or_default(),
        }
    }
    pub fn is_configured(&self) -> bool {
        !self.base_url.is_empty() && !self.email.is_empty() && !self.token.is_empty()
    }
}

pub struct JiraClient {
    config: JiraConfig,
    client: reqwest::Client,
}

impl JiraClient {
    pub fn new(config: JiraConfig) -> Self {
        Self {
            config,
            client: reqwest::Client::new(),
        }
    }

    pub async fn get_issues(&self, params: &IssuesQuery) -> Result<Vec<JiraIssue>, String> {
        params.validate().map_err(|e| format!("Invalid query: {}", e))?;
        if !self.config.is_configured() {
            return Ok(Vec::new());
        }

        let (y, mo) = {
            let mut parts = params.month.split('-');
            (
                parts.next().unwrap_or("0").parse::<i32>().unwrap_or(0),
                parts.next().unwrap_or("0").parse::<u32>().unwrap_or(0),
            )
        };
        let month_start = NaiveDate::from_ymd_opt(y, mo, 1)
            .ok_or_else(|| format!("Invalid month: {}", params.month))?;
        let month_end = month_start
            .checked_add_months(chrono::Months::new(1))
            .ok_or_else(|| format!("Invalid month: {}", params.month))?
            .and_hms_opt(23, 59, 59)
            .ok_or_else(|| format!("Invalid month: {}", params.month))?;

        let project = params.project.clone().unwrap_or_else(|| "MONTHLY".to_string());
        let jql = format!(
            "project = \"{}\" AND created >= {} AND created <= {}",
            project,
            month_start.format("%Y-%m-%dT00:00:00.000+0000"),
            month_end.format("%Y-%m-%dT23:59:59.999+0000")
        );

        let url = format!(
            "{}/rest/api/2/search?jql={}&maxResults=100&fields=summary,status,created,updated,customfield_10014",
            self.config.base_url,
            percent_encoding::utf8_percent_encode(&jql, percent_encoding::NON_ALPHANUMERIC)
        );

        let resp = self
            .client
            .get(&url)
            .basic_auth(&self.config.email, Some(&self.config.token))
            .header("Accept", "application/json")
            .send()
            .await
            .map_err(|e| format!("Jira request failed: {}", e))?;

        let status = resp.status();
        if !status.is_success() {
            let body = resp.text().await.unwrap_or_default();
            return Err(format!("Jira API error: {} - {}", status, body));
        }

        #[derive(Deserialize)]
        struct RawResponse {
            issues: Vec<RawIssue>,
        }
        #[derive(Deserialize)]
        struct RawIssue {
            id: String,
            key: String,
            fields: RawFields,
        }
        #[derive(Deserialize)]
        struct RawFields {
            summary: String,
            status: JiraStatus,
            created: String,
            updated: String,
            #[serde(default, rename = "customfield_10014")]
            epic_key: Option<String>,
        }

        let raw: RawResponse = resp.json().await.map_err(|e| format!("JSON parse error: {}", e))?;
        Ok(raw
            .issues
            .into_iter()
            .map(|issue| JiraIssue {
                id: issue.id,
                key: issue.key,
                summary: issue.fields.summary,
                status: issue.fields.status,
                created: issue.fields.created,
                updated: issue.fields.updated,
                epic: issue.fields.epic_key,
            })
            .collect())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_query_validation_pass() {
        let q = IssuesQuery {
            month: "2024-01".to_string(),
            project: Some("ABC".to_string()),
            include_archived: true,
        };
        assert!(q.validate().is_ok());
    }

    #[test]
    fn test_query_validation_invalid_month() {
        let q = IssuesQuery {
            month: "13-2024".to_string(),
            project: None,
            include_archived: true,
        };
        assert!(q.validate().is_err());
    }
}
