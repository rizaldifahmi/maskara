use axum::{
    extract::{Json, State},
    http::StatusCode,
    response::IntoResponse,
};
use chrono::Utc;
use jsonwebtoken::{encode, EncodingKey, Header};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::models::User;
use crate::routes::AppState;

#[derive(Debug, Deserialize)]
pub struct LoginRequest {
    pub email: String,
    pub password: String,
}

#[derive(Debug, Serialize)]
pub struct LoginResponse {
    pub token: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Claims {
    pub sub: String,
    pub user_id: i32,
    pub exp: usize,
    pub iat: usize,
}

fn create_jwt(user: &User, secret: &str, expiry_seconds: u64) -> Result<String, String> {
    let now = Utc::now().timestamp() as usize;
    let exp = now + expiry_seconds as usize;
    let claims = Claims {
        sub: user.email.clone(),
        user_id: user.id,
        exp,
        iat: now,
    };
    encode(&Header::default(), &claims, &EncodingKey::from_secret(secret.as_bytes()))
        .map_err(|e| e.to_string())
}

fn verify_jwt(token: &str, secret: &str) -> Result<Claims, String> {
    let mut validation = jsonwebtoken::Validation::default();
    validation.validate_exp = true;
    jsonwebtoken::decode::<Claims>(
        token,
        &jsonwebtoken::DecodingKey::from_secret(secret.as_bytes()),
        &validation,
    )
    .map_err(|e| e.to_string())
    .map(|d| d.claims)
    
}

/// POST /api/auth/login - strict single-user login
pub async fn login(
    State(state): State<Arc<AppState>>,
    Json(req): Json<LoginRequest>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    if req.email.trim().is_empty() || req.password.trim().is_empty() {
        return Err((StatusCode::UNAUTHORIZED, "Invalid credentials".into()));
    }

    let user: Option<User> = sqlx::query_as(
        "SELECT id, email, password_hash, name, created_at FROM users WHERE email = $1",
    )
    .bind(req.email.trim())
    .fetch_optional(&state.db)
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    let user = match user {
        Some(u) => u,
        None => return Err((StatusCode::UNAUTHORIZED, "Invalid credentials".into())),
    };

    let valid = bcrypt::verify(&req.password, &user.password_hash)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "bcrypt error".into()))?;
    if !valid {
        return Err((StatusCode::UNAUTHORIZED, "Invalid credentials".into()));
    }

    let token = create_jwt(&user, &state.jwt_secret, state.jwt_expiry_seconds)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;

    Ok(Json(LoginResponse { token }))
}

/// Auth middleware: validates Bearer JWT, returns 401 on any invalid/missing/expired token
pub async fn auth_middleware<B>(
    State(state): State<Arc<AppState>>,
    req: axum::http::Request<B>,
    next: axum::middleware::Next<B>,
) -> Result<axum::response::Response, StatusCode>
where
    B: http_body::Body + Send,
    B::Data: Send,
{
    let auth_header = req
        .headers()
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    let token = match auth_header.strip_prefix("Bearer ") {
        Some(t) if !t.is_empty() => t,
        _ => return Err(StatusCode::UNAUTHORIZED),
    };

    verify_jwt(token, &state.jwt_secret).map_err(|_| StatusCode::UNAUTHORIZED)?;
    Ok(next.run(req).await)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::User;

    fn dummy_user() -> User {
        User {
            id: 1,
            email: "admin@monthly.report".to_string(),
            password_hash: "$2a$10$dummy".to_string(),
            name: "Admin".to_string(),
            created_at: Utc::now(),
        }
    }

    #[test]
    fn test_jwt_roundtrip() {
        let user = dummy_user();
        let token = create_jwt(&user, "secret", 3600).unwrap();
        let claims = verify_jwt(&token, "secret").unwrap();
        assert_eq!(claims.sub, user.email);
        assert_eq!(claims.user_id, user.id);
    }

    #[test]
    fn test_jwt_wrong_secret() {
        let user = dummy_user();
        let token = create_jwt(&user, "secret-a", 3600).unwrap();
        assert!(verify_jwt(&token, "secret-b").is_err());
    }
}
