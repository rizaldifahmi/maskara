use axum::{
    extract::{Query, State},
    http::{HeaderMap, HeaderValue, StatusCode},
    response::IntoResponse,
    Json,
};
use std::sync::Arc;
use crate::{
    docx::DocxGenerator,
    jira::{JiraClient, JiraConfig, IssuesQuery},
    models::ReportData,
    pdf::PdfGenerator,
    templates::TemplateEngine,
};

#[derive(Clone)]
pub struct AppState {
    pub db: sqlx::PgPool,
    pub jira: JiraConfig,
    pub jwt_secret: String,
    pub jwt_expiry_seconds: u64,
    pub templates_dir: String,
}

impl AppState {
    /// Build a real AppState for production (used in main.rs)
    pub async fn new() -> Result<Self, String> {
        let database_url = std::env::var("DATABASE_URL")
            .unwrap_or_else(|_| "postgres://postgres:postgres@localhost:5432/postgres".to_string());
        let db = sqlx::PgPool::connect(&database_url).await.map_err(|e| e.to_string())?;
        Ok(Self {
            db,
            jira: JiraConfig::from_env(),
            jwt_secret: std::env::var("JWT_SECRET")
                .unwrap_or_else(|_| "dev-only-secret-change-in-production".to_string()),
            jwt_expiry_seconds: std::env::var("JWT_EXPIRY_SECONDS")
                .unwrap_or_else(|_| "3600".to_string())
                .parse()
                .unwrap_or(3600),
            templates_dir: "templates".to_string(),
        })
    }

    /// Build AppState for tests with a real DB pool
    pub async fn for_tests() -> Self {
        let database_url = std::env::var("DATABASE_URL")
            .unwrap_or_else(|_| "postgres://postgres:postgres@localhost:5432/postgres".to_string());
        let db = sqlx::PgPool::connect(&database_url).await.expect("test db");
        Self {
            db,
            jira: JiraConfig::from_env(),
            jwt_secret: "test-secret-that-is-long-enough-for-hs256-12345".to_string(),
            jwt_expiry_seconds: 3600,
            templates_dir: "templates".to_string(),
        }
    }
}

pub async fn get_issues(
    State(state): State<Arc<AppState>>,
    Query(params): Query<IssuesQuery>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let client = JiraClient::new(state.jira.clone());
    let issues = client.get_issues(&params).await.map_err(|e| {
        let status = if e.contains("Invalid query") {
            StatusCode::BAD_REQUEST
        } else {
            StatusCode::BAD_GATEWAY
        };
        (status, e)
    })?;
    Ok(Json(issues))
}

pub async fn generate_report(
    State(state): State<Arc<AppState>>,
    Json(data): Json<ReportData>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    if data.consultant_name.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "consultant_name is required".into()));
    }
    if data.project_name.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "project_name is required".into()));
    }
    let engine = TemplateEngine::new(&state.templates_dir);
    let structure = engine
        .generate_report_structure(&data)
        .map_err(|e| {
            let (s, m): (StatusCode, String) = e.into();
            (s, m)
        })?;
    Ok(Json(serde_json::json!({
        "structure": structure,
        "epics_count": data.epics.len(),
        "activities_count": data.activities.len()
    })))
}

pub async fn export_word(
    State(state): State<Arc<AppState>>,
    Json(data): Json<ReportData>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let engine = TemplateEngine::new(&state.templates_dir);
    let vars = engine.build_variables(&data).map_err(|e| {
        let (s, m): (StatusCode, String) = e.into();
        (s, m)
    })?;
    let bytes = DocxGenerator::generate(&data, &vars).map_err(|e| {
        let (s, m): (StatusCode, String) = e.into();
        (s, m)
    })?;
    let mut headers = HeaderMap::new();
    headers.insert("Content-Type", HeaderValue::from_static("application/vnd.openxmlformats-officedocument.wordprocessingml.document"));
    headers.insert("Content-Disposition", HeaderValue::from_str(&format!("attachment; filename=\"{}-{}.docx\"", sanitize_filename(&data.project_name), data.period_start)).unwrap());
    headers.insert("Content-Length", HeaderValue::from_str(&bytes.len().to_string()).unwrap());
    Ok((StatusCode::OK, headers, bytes))
}

pub async fn export_pdf(
    State(_state): State<Arc<AppState>>,
    Json(data): Json<ReportData>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let bytes = PdfGenerator::generate_with_content(&data).map_err(|e| {
        let (s, m): (StatusCode, String) = e.into();
        (s, m)
    })?;
    let mut headers = HeaderMap::new();
    headers.insert("Content-Type", HeaderValue::from_static("application/pdf"));
    headers.insert("Content-Disposition", HeaderValue::from_str(&format!("attachment; filename=\"{}-{}.pdf\"", sanitize_filename(&data.project_name), data.period_start)).unwrap());
    headers.insert("Content-Length", HeaderValue::from_str(&bytes.len().to_string()).unwrap());
    Ok((StatusCode::OK, headers, bytes))
}

fn sanitize_filename(s: &str) -> String {
    s.chars().map(|c| if c.is_alphanumeric() || c == '-' || c == '_' { c } else { '-' }).collect()
}
