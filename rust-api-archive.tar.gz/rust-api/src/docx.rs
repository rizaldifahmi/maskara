use std::io::{Cursor, Read, Write};
use zip::{ZipArchive, ZipWriter};
use zip::write::FileOptions;
use crate::error::ReportEngineError;
use crate::models::{ReportData, Epic, Activity};
use std::collections::HashMap;

/// DOCX generator that loads a verified .docx template and replaces placeholders.
/// Template is embedded via include_bytes! — no filesystem I/O at runtime.
pub struct DocxGenerator;

impl DocxGenerator {
    /// Generate a .docx file by loading the embedded template and replacing
    /// {{VARIABLE}} placeholders with escaped, template-ready values.
    pub fn generate(
        _data: &ReportData,
        variables: &HashMap<String, String>,
    ) -> Result<Vec<u8>, ReportEngineError> {
        // Embedded template — read-only, no temp writes (security: prevents zip-slip/file-system attacks)
        let template_data = include_bytes!("../templates/report_template.docx");

        let reader = Cursor::new(template_data);
        let mut archive = ZipArchive::new(reader)
            .map_err(|e| ReportEngineError::GenerationFailed(format!("Failed to read template ZIP: {}", e)))?;

        let buf = Vec::new();
        let writer = Cursor::new(buf);
        let mut zip = ZipWriter::new(writer);

        for i in 0..archive.len() {
            let file_name = archive.by_index(i).map_err(|e| {
                ReportEngineError::GenerationFailed(format!("Cannot access template entry {}: {}", i, e))
            })?.name().to_string();
            let mut file = archive.by_index(i).map_err(|e| {
                ReportEngineError::GenerationFailed(format!("Cannot access template entry {}: {}", i, e))
            })?;

            zip.start_file(&file_name, FileOptions::default())
                .map_err(|e| ReportEngineError::GenerationFailed(format!("Cannot write output: {}", e)))?;

            if file_name == "word/document.xml" {
                let mut content = String::new();
                file.read_to_string(&mut content)
                    .map_err(|e| ReportEngineError::GenerationFailed(format!("Cannot read XML: {}", e)))?;

                // Template variable replacement (docxtemplater-style):
                // All variables are pre-escaped by TemplateEngine::build_variables.
                for (key, val) in variables {
                    let placeholder = format!("{{{{{}}}}}", key);
                    content = content.replace(&placeholder, val);
                }
                zip.write_all(content.as_bytes())
                    .map_err(|e| ReportEngineError::GenerationFailed(format!("Cannot write XML: {}", e)))?;
            } else {
                std::io::copy(&mut file, &mut zip)
                    .map_err(|e| ReportEngineError::GenerationFailed(format!("Cannot copy template file: {}", e)))?;
            }
        }

        let cursor = zip.finish().map_err(|e| {
            ReportEngineError::GenerationFailed(format!("Failed to finalize ZIP: {}", e))
        })?;
        Ok(cursor.into_inner())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::templates::TemplateEngine;

    /// Fixed sample data used by most tests (deterministic, 1 activity, 2 epics).
    fn sample_data_small() -> ReportData {
        ReportData {
            period_start: "2024-01-01".to_string(),
            period_end: "2024-01-31".to_string(),
            consultant_name: "John Doe".to_string(),
            project_name: "Test Project".to_string(),
            epics: vec![
                Epic { key: "PROJ-1".to_string(), title: "Feature A".to_string(), status: "Done".to_string() },
                Epic { key: "PROJ-2".to_string(), title: "Feature B".to_string(), status: "In Progress".to_string() },
            ],
            activities: vec![
                Activity { date: "2024-01-01".to_string(), description: "Work on A".to_string(), hours: 8.0 },
            ],
        }
    }

    /// Parameterised sample data for the determinism harness (n epics + n activities).
    fn sample_data(n: usize) -> ReportData {
        ReportData {
            period_start: "2024-01-01".to_string(),
            period_end: "2024-01-31".to_string(),
            consultant_name: format!("Consultant-{}", n),
            project_name: format!("Project-{}", n),
            epics: (0..n).map(|i| Epic {
                key: format!("P-{}", i),
                title: format!("Task-{}", i),
                status: format!("Status-{}", i % 3),
            }).collect(),
            activities: (0..n).map(|i| Activity {
                date: format!("2024-01-{:02}", i + 1),
                description: format!("Work-{}", i),
                hours: (i as f64) + 0.5,
            }).collect(),
        }
    }

    /// Generate and return the raw word/document.xml string for given data.
    fn docx_xml_bytes(data: &ReportData) -> Vec<u8> {
        let vars = TemplateEngine::new(".").build_variables(data).unwrap();
        let docx = DocxGenerator::generate(data, &vars).unwrap();

        let mut archive = zip::ZipArchive::new(Cursor::new(&docx))
            .expect("generated docx must be a valid ZIP");
        let mut doc = archive.by_name("word/document.xml")
            .expect("docx must contain word/document.xml");
        let mut out = Vec::new();
        doc.read_to_end(&mut out).unwrap();
        out
    }

    #[test]
    fn test_template_file_is_valid_zip() {
        let cursor = Cursor::new(include_bytes!("../templates/report_template.docx"));
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut names: Vec<String> = Vec::new();
        for i in 0..archive.len() {
            names.push(archive.by_index(i).unwrap().name().to_string());
        }
        let has_doc = names.iter().any(|n| n == "word/document.xml");
        let has_ct = names.iter().any(|n| n == "[Content_Types].xml");
        assert!(has_doc, "template must contain word/document.xml");
        assert!(has_ct, "template must contain [Content_Types].xml");
    }

    #[test]
    fn test_generate_docx_produces_valid_zip() {
        let data = sample_data_small();
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        // Verify ZIP signature
        assert!(docx.len() > 4);
        assert_eq!(&docx[0..2], b"PK");

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        assert!(archive.by_name("[Content_Types].xml").is_ok());
        assert!(archive.by_name("word/document.xml").is_ok());
    }

    #[test]
    fn test_placeholders_replaced_in_output() {
        let data = sample_data_small();
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        // Template values should be present
        assert!(content.contains("Test Project"), "project name should be in output");
        assert!(content.contains("John Doe"), "consultant name should be in output");
        assert!(content.contains("2024-01-01"), "period start should be in output");
        // No unreplaced placeholders for basic fields
        assert!(!content.contains("{{PROJECT_NAME}}"), "PROJECT_NAME placeholder must be replaced");
        assert!(!content.contains("{{CONSULTANT_NAME}}"), "CONSULTANT_NAME placeholder must be replaced");
    }

    #[test]
    fn test_epic_and_activity_rows_in_output() {
        let data = sample_data_small();
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        // Epic rows
        assert!(content.contains("PROJ-1"), "first epic key should appear");
        assert!(content.contains("Feature A"), "first epic title should appear");
        // Activity rows
        assert!(content.contains("Work on A"), "activity description should appear");
        // No unreplaced table placeholders
        assert!(!content.contains("{{EPICS_TABLE_ROWS}}"), "EPICS_TABLE_ROWS must be replaced");
        assert!(!content.contains("{{ACTIVITIES_TABLE_ROWS}}"), "ACTIVITIES_TABLE_ROWS must be replaced");
    }

    #[test]
    fn test_empty_epics_generates_valid_doc() {
        let data = ReportData {
            period_start: "2024-01-01".to_string(),
            period_end: "2024-01-31".to_string(),
            consultant_name: "Jane".to_string(),
            project_name: "Empty Project".to_string(),
            epics: vec![],
            activities: vec![],
        };
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        // Empty table placeholders replaced with empty string
        assert!(!content.contains("{{EPICS_TABLE_ROWS}}"));
        assert!(!content.contains("{{ACTIVITIES_TABLE_ROWS}}"));
        assert!(content.contains("Empty Project"));
    }

    #[test]
    fn test_xml_escaping_in_template_values() {
        let data = ReportData {
            period_start: "2024-01-01".to_string(),
            period_end: "2024-01-31".to_string(),
            consultant_name: "John & Mary <Smith>".to_string(),
            project_name: "X\"Y'Z".to_string(),
            epics: vec![],
            activities: vec![],
        };
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        // XML special chars should be escaped in the output
        assert!(content.contains("John &amp; Mary &lt;Smith&gt;"), "special chars must be escaped");
        assert!(!content.contains("John & Mary <Smith>"), "raw unescaped chars must not appear");
    }

    #[test]
    fn test_total_hours_in_output() {
        let data = sample_data_small();
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        // Total hours = 8.0h from one activity
        assert!(content.contains("8.0"), "total hours should appear in output");
    }

    #[test]
    fn test_unicode_data_in_template() {
        let data = ReportData {
            period_start: "2024-01-01".to_string(),
            period_end: "2024-01-31".to_string(),
            consultant_name: "Budi Ahmad Putra".to_string(),
            project_name: "Projek Data - Dashboard".to_string(),
            epics: vec![
                Epic { key: "PROJ-1".to_string(), title: "Implementasi fitur A".to_string(), status: "Selesai".to_string() },
            ],
            activities: vec![
                Activity { date: "2024-01-01".to_string(), description: "Kerja pada fitur A".to_string(), hours: 7.5 },
            ],
        };
        let engine = TemplateEngine::new(".");
        let vars = engine.build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        let cursor = Cursor::new(&docx);
        let mut archive = zip::ZipArchive::new(cursor).unwrap();
        let mut doc = archive.by_name("word/document.xml").unwrap();
        let mut content = String::new();
        doc.read_to_string(&mut content).unwrap();

        assert!(content.contains("Budi Ahmad Putra"));
        assert!(content.contains("Implementasi fitur A"));
        assert!(content.contains("Kerja pada fitur A"));
    }

    // -----------------------------------------------------------------
    // Determinism & harness helpers
    //
    // These tests make DocxGenerator's buffer contract explicit:
    //  * the output is a deterministic function of (template, variables)
    //  * the output is a valid OOXML ZIP that every tool can open
    //  * the same input repeated N times yields byte-identical output
    //  * different inputs yield different outputs (no cross-bleed)
    //
    // Run with `cargo test` — every assertion runs per-call, so any
    // non-determinism in the ZIP writer, ordering, or hashing logic
    // surfaces as a hard failure in CI.
    // -----------------------------------------------------------------

    /// Run DocxGenerator N times with the same input; output must be
    /// byte-identical across all runs.
    #[test]
    fn test_docx_output_is_byte_identical_across_runs() {
        let data = sample_data(1);
        let expected = docx_xml_bytes(&data);

        for i in 1..=5 {
            let got = docx_xml_bytes(&data);
            assert_eq!(
                &got, &expected,
                "run {} produced different bytes",
                i
            );
        }
    }

    /// Each distinct input must yield a distinct output (no buffer aliasing).
    #[test]
    fn test_docx_output_differs_for_distinct_inputs() {
        let a = docx_xml_bytes(&sample_data(1));
        let b = docx_xml_bytes(&sample_data(2));
        let c = docx_xml_bytes(&sample_data(3));

        assert_ne!(a, b, "different epics count should not produce same output");
        assert_ne!(b, c);
        assert_ne!(a, c);
    }

    /// Empty report produces a well-formed ZIP with empty table rows.
    #[test]
    fn test_empty_report_docx_is_valid_zip_with_empty_rows() {
        let data = sample_data(0);
        let docx = DocxGenerator::generate(&data, &TemplateEngine::new(".").build_variables(&data).unwrap())
            .unwrap();
        let mut archive = zip::ZipArchive::new(Cursor::new(&docx)).unwrap();
        let mut content = String::new();
        archive.by_name("word/document.xml").unwrap().read_to_string(&mut content).unwrap();

        // All placeholders must be replaced, even when empty
        assert!(!content.contains("{{"), "empty report must have no leftover placeholders");
        // And still parseable as XML
        assert!(content.starts_with("<?xml") || content.starts_with('<'), "document.xml must be XML");
        // Zero epics / zero activities — row tables are empty
        assert!(!content.contains("<tr>"));
    }

    /// A report with 200 epics + 200 activities still generates a valid,
    /// deterministic docx buffer (regression test against unbounded input).
    #[test]
    fn test_large_report_docx_is_valid_zip() {
        let data = sample_data(200);
        let vars = TemplateEngine::new(".").build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();
        assert!(docx.len() > 500, "large report ZIP should be sizable");

        // Must open as ZIP and contain document.xml
        let mut archive = zip::ZipArchive::new(Cursor::new(&docx)).unwrap();
        let mut content = String::new();
        archive.by_name("word/document.xml").unwrap().read_to_string(&mut content).unwrap();
        assert_eq!(content.matches("<tr>").count(), 400, "200 epic rows + 200 activity rows expected");
    }

    /// Round-trip through an actual docx parser: the buffer must satisfy
    /// the OLE/ZIP signature check, which catches silent corruption
    /// (wrong endianness, truncated central directory, corrupted CRC).
    #[test]
    fn test_generated_docx_roundtrips_through_zip_library() {
        let data = sample_data(2);
        let vars = TemplateEngine::new(".").build_variables(&data).unwrap();
        let docx = DocxGenerator::generate(&data, &vars).unwrap();

        // 1) ZIP magic
        assert_eq!(&docx[0..2], b"PK", "ZIP central-dir must start with PK");

        // 2) Read back every entry and verify CRC (the default ZipArchive
        //    does this; failure => Err, which `.unwrap()` turns into a
        //    hard test failure)
        let mut archive = zip::ZipArchive::new(Cursor::new(&docx)).unwrap();
        let mut saw_document = false;
        for i in 0..archive.len() {
            let mut entry = archive.by_index(i).unwrap();
            if entry.name() == "word/document.xml" {
                saw_document = true;
            }
            let mut buf = Vec::new();
            entry.read_to_end(&mut buf).unwrap();
        }
        assert!(saw_document, "ZIP must contain word/document.xml");
    }

    /// The raw ZIP bytes (including the template's non-XML parts) must
    /// be byte-stable across runs. This catches non-determinism in
    /// ZipWriter's entry order / timestamps.
    #[test]
    fn test_full_docx_buffer_is_deterministic_across_runs() {
        let data = sample_data(1);
        let vars = TemplateEngine::new(".").build_variables(&data).unwrap();
        let buf1 = DocxGenerator::generate(&data, &vars).unwrap();
        let buf2 = DocxGenerator::generate(&data, &vars).unwrap();
        assert_eq!(buf1, buf2, "raw docx buffer must be byte-identical for the same input");
    }
}
