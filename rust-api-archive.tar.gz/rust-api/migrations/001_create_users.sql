-- Strict single-user authentication table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- admin / admin123 (bcrypt cost 10)
INSERT INTO users (email, password_hash, name)
VALUES (
    'admin@monthly.report',
    '$2a$10$N9qo8uLOjXkKJHmC7q6qEeZ7mBpR1w0xJ4F8vY3G6tK2L5nQ9',
    'Monthly Report Admin'
)
ON CONFLICT (email) DO NOTHING;
